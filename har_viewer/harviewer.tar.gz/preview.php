<!doctype html>
<html>
<head>
    <title>HTTP Archive Preview 2.0.17</title>
    <link rel="stylesheet" href="css/harPreview.css" type="text/css">
</head>
<body style="margin:0">
    <div id="content" version="2.0.17"></div>
    <script src="scripts/jquery.js"></script>
    <script data-main="scripts/harPreview" src="scripts/require.js"></script>
    <?php include("ga.php") ?>
</body>
</html>
